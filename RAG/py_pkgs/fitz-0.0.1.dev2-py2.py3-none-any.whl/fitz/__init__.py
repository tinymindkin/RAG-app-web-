from frontend import *
import tools
import os.path as op

__version__ = '0.0.1dev2'
__license__ = 'BSD-3'
__author__ = 'Erik Kastman'
__author_email__ = 'erik.kastman@gmail.com'
__maintainer_email__ = 'erik.kastman@gmail.com'
__url__ = 'https://github.com/kastman/fitz'
__downloadUrl__ = 'https://github.com/kastman/fitz/releases'
